$(function(){
     $('#left').load("users.html");
     load_content();     
     
});

//loading content in and outside view
var load_content = function(){
    $('.load-content').click(function(){
        
        $('#left').load($(this).attr("id")+".html");
    });
}

//validating user data b4 sumission

var validate_userData = function(){


    var user = {firstName:$("#firstName").val(),
                surName:$("#surName").val(),
                gender:$(".gender").attr("value"),
                mobile:$("#mobile").val(),
                email:$("#email").val(),
                usertype:$("#usertype").val()
        };
        var errmsg="<span class=\"errmsg\">*required</span>";
 
    
                if(user.firstName===""){

                    $('.msg').html("");
                   $('.msg').html("*firstName is required");
                    
                }
                else if(user.surName===""){
                    
                   $('.msg').html("");
                   $('.msg').html("*surName is required");
                }
               else if(!user.mobile.match(/^[0-9]+$/)){

                   $('.msg').html("");
                   $('.msg').html("*invalid mobile number format ");
                }
                else if(!user.email.match(/^\w+([-+.'][^\s]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/)){

                    $('.msg').html("");
                   $('.msg').html("*invalid email");
                }
                else {
                     $('.msg').html("");
                    $('.msg').html("user created successfully");
                }
        }

        //clearing  user forms

        var clearUserData = function(){
            document.getElementById('user-reg-form').reset();
             $('.msg').html("");
                          
        }
        var clearTravelplan = function(){
            document.getElementById('Trav-plan').reset();
             $('.msg').html("");
        }
        var clearprojData = function(){
            document.getElementById('proj').reset();
             $('.msg').html("");
        }